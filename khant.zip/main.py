"""FastAPI Server for One Team Telegram Bot Studio"""

import os
import uuid
import json
import time
import threading
import requests
from datetime import datetime, timedelta, timezone
from pathlib import Path
from fastapi import FastAPI, Request, BackgroundTasks
from pydantic import BaseModel
import media_engine

app = FastAPI(title="One Team Bot Studio")

# ==========================================
# 📂 Folders & Setup
# ==========================================
ROOT = Path(__file__).resolve().parent
UPLOAD_DIR = ROOT / "uploads"
OUTPUT_DIR = ROOT / "outputs"
for folder in [UPLOAD_DIR, OUTPUT_DIR]:
    folder.mkdir(parents=True, exist_ok=True)

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
BASE_URL = os.getenv("BASE_URL", "").strip()
ADMIN_CHAT_ID = os.getenv("ADMIN_CHAT_ID", "").strip()

@app.on_event("startup")
async def setup_webhook():
    if BOT_TOKEN and BASE_URL:
        webhook_url = f"{BASE_URL}/api/telegram/webhook"
        requests.get(f"https://api.telegram.org/bot{BOT_TOKEN}/setWebhook?url={webhook_url}", timeout=10)
        print("Telegram Webhook Set:", webhook_url)

# ==========================================
# 💾 Database (JSON / Local Storage)
# ==========================================
def save_data(type_str: str, id_str: str, data: dict):
    path = UPLOAD_DIR / f"{type_str}_{id_str}.json"
    path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")

def load_data(type_str: str, id_str: str) -> dict:
    path = UPLOAD_DIR / f"{type_str}_{id_str}.json"
    if path.exists():
        try: return json.loads(path.read_text(encoding="utf-8"))
        except: pass
    return {}

def get_user(tg_id: str) -> dict:
    user = load_data("user", str(tg_id))
    if not user:
        # API Key သိမ်းရန် api_key အကွက် ထပ်ဖြည့်ထားပါသည်
        user = {"tg_id": tg_id, "free_used": 0, "vip_expire": None, "state": "idle", "api_key": ""}
        save_data("user", str(tg_id), user)
    return user

def update_user(tg_id: str, updates: dict):
    user = get_user(tg_id)
    user.update(updates)
    save_data("user", str(tg_id), user)

def is_vip(user: dict) -> bool:
    if str(user["tg_id"]) == ADMIN_CHAT_ID: return True
    expiry = user.get("vip_expire")
    if not expiry: return False
    expire_date = datetime.fromisoformat(expiry)
    return expire_date > datetime.now(timezone.utc)

# ==========================================
# 📨 Telegram API Helpers
# ==========================================
def tg_send_message(chat_id, text, reply_markup=None):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    payload = {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}
    if reply_markup: payload["reply_markup"] = reply_markup
    requests.post(url, json=payload, timeout=10)

def tg_edit_message(chat_id, message_id, text, reply_markup=None):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/editMessageText"
    payload = {"chat_id": chat_id, "message_id": message_id, "text": text, "parse_mode": "HTML"}
    if reply_markup: payload["reply_markup"] = reply_markup
    requests.post(url, json=payload, timeout=10)

def tg_send_video(chat_id, video_path, caption=""):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendVideo"
    with open(video_path, 'rb') as video:
        requests.post(url, data={"chat_id": chat_id, "caption": caption, "parse_mode": "HTML"}, files={"video": video}, timeout=600)

def tg_forward_message(to_chat_id, from_chat_id, message_id):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/forwardMessage"
    requests.post(url, json={"chat_id": to_chat_id, "from_chat_id": from_chat_id, "message_id": message_id}, timeout=10)

def get_telegram_file_url(file_id: str) -> str:
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/getFile?file_id={file_id}"
    res = requests.get(url, timeout=10).json()
    if res.get("ok"):
        file_path = res["result"]["file_path"]
        return f"https://api.telegram.org/file/bot{BOT_TOKEN}/{file_path}"
    return ""

# ==========================================
# 🤖 BOT WEBHOOK HANDLER
# ==========================================
@app.post("/api/telegram/webhook")
async def telegram_webhook(request: Request, background_tasks: BackgroundTasks):
    payload = await request.json()
    
    # --- 🔘 Callback Queries (ခလုတ်နှိပ်ခြင်းများ) ---
    if "callback_query" in payload:
        cb = payload["callback_query"]
        chat_id = str(cb["message"]["chat"]["id"])
        msg_id = cb["message"]["message_id"]
        data = str(cb["data"])
        user = get_user(chat_id)

        # Admin Approval
        if data.startswith("approve_"):
            _, target_id, days = data.split("_")
            target_user = get_user(target_id)
            now = datetime.now(timezone.utc)
            current_expiry = datetime.fromisoformat(target_user["vip_expire"]) if target_user.get("vip_expire") else now
            new_expiry = max(now, current_expiry) + timedelta(days=int(days))
            update_user(target_id, {"vip_expire": new_expiry.isoformat()})
            tg_edit_message(ADMIN_CHAT_ID, msg_id, f"✅ <b>အတည်ပြုပြီးပါပြီ။</b> (ID: {target_id} အား {days} ရက် တိုးပေးလိုက်ပါသည်)")
            tg_send_message(target_id, f"🎉 <b>ဂုဏ်ယူပါတယ်။</b> လူကြီးမင်း၏ အကောင့် VIP {days} ရက် ရရှိသွားပါပြီ။ ယခုပဲ Video များကို Unlimited စတင်ဖန်တီးနိုင်ပါပြီ။")
            return {"status": "ok"}
            
        if data.startswith("reject_"):
            target_id = data.split("_")[1]
            tg_edit_message(ADMIN_CHAT_ID, msg_id, f"❌ <b>ပယ်ဖျက်လိုက်ပါသည်။</b> (ID: {target_id})")
            tg_send_message(target_id, "❌ သင့်၏ ငွေလွှဲပြေစာကို Admin မှ ပယ်ဖျက်လိုက်ပါသည်။ အချက်အလက်များ မှန်ကန်မှုရှိမရှိ ပြန်လည်စစ်ဆေးပါ။")
            return {"status": "ok"}

        # Set API Key Button
        if data == "set_api_key":
            update_user(chat_id, {"state": "waiting_api_key"})
            tg_edit_message(chat_id, msg_id, "🔑 <b>Gemini API Key ကို ရိုက်ထည့်ပေးပါ:</b>\n\n(AI Studio မှ အခမဲ့ ရယူထားသော 'AIza...' ဖြင့်စသည့် Key ဖြစ်ရမည်)")
            return {"status": "ok"}

        # VIP Buy Menu
        if data == "buy_vip":
            txt = "👑 <b>One Team VIP Plan</b>\n\n💰 ဈေးနှုန်း: ၂၅,၀၀၀ ကျပ် / ၃၀ ရက်\n🔥 အကျိုးကျေးဇူး: ၁၀ မိနစ်အထိ Video များ Unlimited ထုတ်လုပ်နိုင်ပါသည်။\n\n💳 <b>KPay:</b> 09670132806 (Nay Lin Aung)\n💳 <b>WavePay:</b> 09670132806 (Nay Lin Aung)\n\nငွေလွှဲပြီးပါက <b>ငွေလွှဲပြေစာ (Slip) ဓာတ်ပုံကို ဤနေရာသို့ ပို့ပေးပါ။</b>"
            update_user(chat_id, {"state": "waiting_slip"})
            tg_edit_message(chat_id, msg_id, txt)
            return {"status": "ok"}

        # Job Configuration Menu
        if "_" in data and data.split("_")[0] in ["type", "voice", "logo"]:
            action, val, job_id = data.split("_", 2)
            job = load_data("job", job_id)
            if not job: return {"status": "error"}

            if action == "type":
            job["settings"]["recapType"] = val.replace("-", " ")
            save_data("job", job_id, job)
            # အသံ ၁၂ မျိုးလုံးကို တစ်တန်းလျှင် ၂ မျိုးစီဖြင့် ခလုတ် (၆) တန်း ခွဲထားခြင်း
            kb = {"inline_keyboard": [
                [{"text": "👩 နီလာ", "callback_data": f"voice_Nilar_{job_id}"}, {"text": "👨 သီဟ", "callback_data": f"voice_Thiha_{job_id}"}],
                [{"text": "👩 အေးမြတ်", "callback_data": f"voice_Ava_{job_id}"}, {"text": "👨 အောင်ဒင်", "callback_data": f"voice_Andrew_{job_id}"}],
                [{"text": "👩 အိအိမွန်", "callback_data": f"voice_Emma_{job_id}"}, {"text": "👨 ဘုန်းမြတ်", "callback_data": f"voice_Brian_{job_id}"}],
                [{"text": "👩 ဝေဝေခိုင်", "callback_data": f"voice_Vivienne_{job_id}"}, {"text": "👨 ရဲရင့်အောင်", "callback_data": f"voice_Remy_{job_id}"}],
                [{"text": "👩 စန္ဒီ", "callback_data": f"voice_Seraphina_{job_id}"}, {"text": "👨 ဖြိုးမင်း", "callback_data": f"voice_Florian_{job_id}"}],
                [{"text": "👩 ဆုဆုလှိုင်", "callback_data": f"voice_Xiaoxiao_{job_id}"}, {"text": "👨 ဂျော်နီ", "callback_data": f"voice_Giuseppe_{job_id}"}]
            ]}
            tg_edit_message(chat_id, msg_id, f"✅ အမျိုးအစားရွေးချယ်ပြီးပါပြီ။\n\n🎙 <b>AI အသံ ရွေးချယ်ပါ:</b>", reply_markup=kb)

            elif action == "voice":
                job["settings"]["voice"] = val
                save_data("job", job_id, job)
                kb = {"inline_keyboard": [
                    [{"text": "✅ Logo အလိုအလျောက် ထည့်မည်", "callback_data": f"logo_yes_{job_id}"}],
                    [{"text": "❌ မထည့်ပါ", "callback_data": f"logo_no_{job_id}"}]
                ]}
                tg_edit_message(chat_id, msg_id, f"✅ အသံရွေးချယ်ပြီးပါပြီ။\n\n🖼 <b>One Team Logo ထည့်မည်လား?</b>", reply_markup=kb)

            elif action == "logo":
                job["settings"]["logo_enabled"] = (val == "yes")
                job["settings"]["test_logo_enabled"] = (val == "yes")
                save_data("job", job_id, job)
                
                settings_str = f"🔹 အမျိုးအစား: {job['settings'].get('recapType')}\n🔹 အသံ: {job['settings'].get('voice')}\n🔹 Logo: {'ပါဝင်သည်' if val=='yes' else 'မပါပါ'}"
                txt = f"🎬 <b>အချက်အလက်များ ပြည့်စုံပါပြီ!</b>\n\n📌 <b>ရွေးချယ်ထားမှုများ</b>\n{settings_str}\n\n<i>⏳ အောက်ပါခလုတ်ကိုနှိပ်၍ စတင်ပါ...</i>"
                
                # API Key ရှိ/မရှိ စစ်ဆေးပြီး ခလုတ်ပြခြင်း
                buttons = []
                if not user.get("api_key"):
                    buttons.append([{"text": "🔑 စတင်ရန် API Key အရင်ထည့်ပါ", "callback_data": "set_api_key"}])
                else:
                    buttons.append([{"text": "🚀 ဗီဒီယို စတင်ဖန်တီးမည်", "callback_data": f"start_{job_id}"}])
                    buttons.append([{"text": "🔑 API Key အသစ်ပြောင်းမည်", "callback_data": "set_api_key"}])
                    
                tg_edit_message(chat_id, msg_id, txt, reply_markup={"inline_keyboard": buttons})

        # Start Processing
        if data.startswith("start_"):
            if not user.get("api_key"):
                tg_send_message(chat_id, "⚠️ <b>API Key မရှိသေးပါ။</b>\nကျေးဇူးပြု၍ API Key ကို အရင်ထည့်သွင်းပေးပါ။", reply_markup={"inline_keyboard": [[{"text": "🔑 API Key ထည့်ရန်", "callback_data": "set_api_key"}]]})
                return {"status": "ok"}
                
            job_id = data.replace("start_", "")
            tg_edit_message(chat_id, msg_id, "⚙️ <b>Video ကို ဆာဗာမှ စတင်ဖန်တီးနေပါပြီ...</b> ကျေးဇူးပြု၍ ခဏစောင့်ပါ။")
            background_tasks.add_task(process_video_task, chat_id, job_id)

        return {"status": "ok"}

    # --- 💬 Messages (စာပို့ခြင်း / ဖိုင်ပို့ခြင်း) ---
    if "message" in payload:
        msg = payload["message"]
        chat_id = str(msg["chat"]["id"])
        text = msg.get("text", "")
        user = get_user(chat_id)

        # 🔑 User မှ API Key ထည့်သွင်းခြင်း လက်ခံခြင်း
        if user.get("state") == "waiting_api_key" and text:
            update_user(chat_id, {"api_key": text.strip(), "state": "idle"})
            tg_send_message(chat_id, "✅ <b>Gemini API Key မှတ်သားပြီးပါပြီ။</b>\n\nVideo ပြန်ပို့၍ (သို့) ခုနက လုပ်လက်စမှ ဆက်လက် ဖန်တီးနိုင်ပါပြီ။")
            return {"status": "ok"}

        # Admin Commands
        if text.startswith("/addvip") and chat_id == ADMIN_CHAT_ID:
            try:
                _, target_id, days = text.split(" ")
                target_user = get_user(target_id)
                now = datetime.now(timezone.utc)
                current_expiry = datetime.fromisoformat(target_user["vip_expire"]) if target_user.get("vip_expire") else now
                new_expiry = max(now, current_expiry) + timedelta(days=int(days))
                update_user(target_id, {"vip_expire": new_expiry.isoformat()})
                tg_send_message(chat_id, f"✅ ID {target_id} အား {days} ရက် VIP တိုးပေးပြီးပါပြီ။")
                tg_send_message(target_id, f"🎉 Admin မှ သင့်အကောင့်အား VIP {days} ရက် တိုးပေးလိုက်ပါသည်။")
            except:
                tg_send_message(chat_id, "⚠️ အသုံးပြုပုံ မှားယွင်းနေပါသည်။ (ဥပမာ: /addvip 123456789 30)")
            return {"status": "ok"}

        if text.startswith("/start"):
            kb = {"inline_keyboard": [
                [{"text": "👑 VIP အကြောင်းလေ့လာရန်", "callback_data": "buy_vip"}],
                [{"text": "🔑 ကိုယ်ပိုင် API Key ထည့်ရန်", "callback_data": "set_api_key"}]
            ]}
            tg_send_message(chat_id, "👋 မင်္ဂလာပါ <b>One Team Movie Recap Bot</b> မှ ကြိုဆိုပါတယ်။\n\nအသုံးမပြုမီ <b>ကိုယ်ပိုင် Gemini API Key</b> ကို အရင်ထည့်သွင်းပေးပါ။ ပြီးပါက <b>Video ဖိုင်တစ်ခု (သို့) YouTube/TikTok Link ကို ဤနေရာသို့ ပို့ပေးပါဗျ။</b>", reply_markup=kb)
            return {"status": "ok"}

        # Handle Payment Slip Image
        if "photo" in msg and user.get("state") == "waiting_slip":
            update_user(chat_id, {"state": "idle"})
            tg_send_message(chat_id, "✅ ပြေစာ လက်ခံရရှိပါပြီ။ Admin မှ စစ်ဆေးပြီးပါက အကြောင်းကြားပေးပါမည်။")
            
            if ADMIN_CHAT_ID:
                tg_send_message(ADMIN_CHAT_ID, f"🔔 <b>ငွေလွှဲပြေစာ အသစ်ရောက်ရှိ!</b>\n👤 User ID: <code>{chat_id}</code>")
                tg_forward_message(ADMIN_CHAT_ID, chat_id, msg["message_id"])
                admin_kb = {"inline_keyboard": [
                    [{"text": "✅ အတည်ပြုမည် (၃၀ ရက်)", "callback_data": f"approve_{chat_id}_30"}],
                    [{"text": "❌ ပယ်ဖျက်မည်", "callback_data": f"reject_{chat_id}"}]
                ]}
                tg_send_message(ADMIN_CHAT_ID, "အထက်ပါ ပြေစာကို စစ်ဆေးပြီး Action ယူပါ 👇", reply_markup=admin_kb)
            return {"status": "ok"}

        # Handle Video or Link Input
        is_video = "video" in msg or "document" in msg
        is_link = text.startswith("http")
        
        if is_video or is_link:
            # Check Limits First
            if not is_vip(user):
                if user["free_used"] >= 2:
                    kb = {"inline_keyboard": [[{"text": "👑 VIP ဝယ်ယူမည်", "callback_data": "buy_vip"}]]}
                    tg_send_message(chat_id, "⚠️ လူကြီးမင်း၏ <b>အခမဲ့ထုတ်လုပ်ခွင့် (၂) ပုဒ် ပြည့်သွားပါပြီ။</b> ဆက်လက်အသုံးပြုလိုပါက VIP Plan ဝယ်ယူပါ။", reply_markup=kb)
                    return {"status": "ok"}

            # Create Job
            job_id = str(uuid.uuid4())
            job = {
                "job_id": job_id, "chat_id": chat_id, "is_link": is_link, "link_url": text if is_link else "",
                "file_id": msg["video"]["file_id"] if "video" in msg else (msg["document"]["file_id"] if "document" in msg else ""),
                "settings": {"recapType": "Movie Recap", "voice": "Nilar", "logo_enabled": False, "speed": 1.0, "language": "Myanmar", "tone": "Cinematic"}
            }
            save_data("job", job_id, job)

            # Show Type Selection Keyboard
            kb = {"inline_keyboard": [
                [{"text": "🎬 Movie Recap", "callback_data": f"type_Movie-Recap_{job_id}"}],
                [{"text": "🗣 Movie Dub", "callback_data": f"type_Movie-Dub_{job_id}"}],
                [{"text": "🔕 Silent Recap", "callback_data": f"type_Silent-Recap_{job_id}"}],
                [{"text": "🎞 Raw to Recap", "callback_data": f"type_Raw-to-Recap_{job_id}"}]
            ]}
            tg_send_message(chat_id, "📥 <b>Video လက်ခံရရှိပါပြီ။</b>\n\n👇 ဖန်တီးလိုသော အမျိုးအစားကို ရွေးချယ်ပါ:", reply_markup=kb)

    return {"status": "ok"}


# ==========================================
# ⚙️ BACKGROUND PROCESSING
# ==========================================
def process_video_task(chat_id: str, job_id: str):
    job = load_data("job", job_id)
    if not job: return
    user = get_user(chat_id)
    api_key = user.get("api_key", "").strip()
    
    if not api_key:
        tg_send_message(chat_id, "❌ API Key မရှိပါ။ ကျေးဇူးပြု၍ /start နှိပ်ပြီး API Key အရင်ထည့်ပါ။")
        return
        
    tg_send_message(chat_id, "🔄 <i>ဗီဒီယို ဖိုင်ကို ဆာဗာသို့ ရယူနေပါသည်...</i>")
    
    try:
        video_path = UPLOAD_DIR / f"vid_{job_id}.mp4"
        
        # Download Logic
        if job["is_link"]:
            import yt_dlp
            ydl_opts = {'format': 'best[height<=720]/best', 'outtmpl': str(video_path), 'quiet': True}
            with yt_dlp.YoutubeDL(ydl_opts) as ydl: ydl.extract_info(job["link_url"], download=True)
            for ext in ['mp4', 'mkv', 'webm']:
                check_path = UPLOAD_DIR / f"vid_{job_id}.{ext}"
                if check_path.exists():
                    video_path = check_path
                    break
        else:
            file_url = get_telegram_file_url(job["file_id"])
            if not file_url: raise Exception("Telegram ဖိုင်ဆိုဒ် ကြီးလွန်းပါသည် (20MB ကန့်သတ်ချက်)။ ကျေးဇူးပြု၍ YouTube/TikTok Link ဖြင့် ပို့ပေးပါ။")
            r = requests.get(file_url, stream=True)
            with open(video_path, 'wb') as f:
                for chunk in r.iter_content(1024*1024): f.write(chunk)

        if not video_path.exists(): raise Exception("ဗီဒီယို ဒေါင်းလုဒ်ဆွဲ၍ မရပါ။")

        info = media_engine.probe_video(video_path)
        duration = float(info.get("duration", 0))

        tg_send_message(chat_id, "📝 <i>AI မှ ဇာတ်ညွှန်း ရေးသားနေပါသည်...</i>")
        settings = job["settings"]
        
        # User ၏ API Key ကို အသုံးပြုခြင်း
        script = media_engine.generate_script(api_key, video_path, "video/mp4", "Myanmar", int(duration), settings.get("tone"), settings.get("recapType"), "Natural", None)
        settings["script"] = script

        tg_send_message(chat_id, "🗣 <i>အသံ ထုတ်လုပ်နေပါသည်...</i>")
        tts_wav = media_engine.generate_microsoft_tts(script, settings.get("voice", "Nilar"))

        tg_send_message(chat_id, "⏳ <i>နောက်ဆုံးအဆင့် ဗီဒီယို ပေါင်းစပ်နေပါသည်...</i>")
        out_file = OUTPUT_DIR / f"final_{job_id}.mp4"
        media_engine.render_final(video_path, tts_wav, settings, out_file)

        # Deduct Free Usage if not VIP
        if not is_vip(user):
            update_user(chat_id, {"free_used": user["free_used"] + 1})

        # Send Video Back
        tg_send_video(chat_id, out_file, caption="✅ <b>One Team Movie Recap ပြီးစီးပါပြီ!</b>\n\n<i>✨ ကျေးဇူးတင်ပါတယ်။</i>")

        # Cleanup
        if video_path.exists(): video_path.unlink()
        if out_file.exists(): out_file.unlink()

    except Exception as e:
        tg_send_message(chat_id, f"❌ <b>အမှားအယွင်း ဖြစ်ပေါ်ခဲ့ပါသည်:</b>\n<code>{str(e)}</code>")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=int(os.getenv("PORT", 8080)))