"""Small deterministic FFmpeg smoke test for the final media pipeline."""

from __future__ import annotations

import math
import shutil
import subprocess
import sys
import tempfile
import wave
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from media_engine import probe_video, render_final


def create_test_audio(path: Path) -> None:
    rate = 24000
    frames = bytearray()
    for index in range(rate * 2):
        value = int(8000 * math.sin(2 * math.pi * 440 * index / rate))
        frames.extend(value.to_bytes(2, "little", signed=True))
    with wave.open(str(path), "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(rate)
        wav.writeframes(bytes(frames))


def main() -> None:
    folder = Path(tempfile.mkdtemp(prefix="one-team-render-check-"))
    source, narration, output = folder / "source.mp4", folder / "narration.wav", folder / "final.mp4"
    try:
        subprocess.run([
            "ffmpeg", "-y", "-f", "lavfi", "-i", "testsrc2=size=360x640:rate=24", "-t", "3",
            "-c:v", "libx264", "-pix_fmt", "yuv420p", str(source),
        ], check=True, capture_output=True, text=True)
        create_test_audio(narration)
        render_final(source, narration.read_bytes(), {
            "aspect": "9:16", "quality": "720p", "mirror": True, "auto_zoom": True,
            "color_filter": True, "background_blur": True, "pitch_alter": True,
            "subtitles": True, "subtitle_font": "Pyidaungsu Bold", "subtitle_size": 26,
            "subtitle_color": "#FFD166", "subtitle_outline": "#000000", "subtitle_background": "Transparent",
            "subtitle_opacity": 55, "subtitle_x": 51, "subtitle_y": 70,
            "subtitle_srt": "1\n00:00:00,000 --> 00:00:01,800\nKhant Happy · စာတန်းထိုး\n",
            "blur_masks": [{"x": 0.2, "y": 0.18, "width": 0.35, "height": 0.15}],
            "logo_enabled": True, "logo_text": "Khant Happy · ကိုခန့်", "logo_size": 27, "logo_x": 78, "logo_y": 84,
            "original_audio": "Mute", "music_path": "",
        }, output)
        info = probe_video(output)
        assert output.exists() and output.stat().st_size > 30_000
        assert int(info["width"]) == 720 and int(info["height"]) == 1280
        print(f"final render smoke test passed: {output.stat().st_size} bytes, {info['width']}x{info['height']}")
    finally:
        shutil.rmtree(folder, ignore_errors=True)


if __name__ == "__main__":
    main()
