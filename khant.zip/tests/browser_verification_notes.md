# Browser Verification Notes

## 2026-08-27 local run

The editor opened at `http://127.0.0.1:8080` with the expected One Team title and the Simple Free key sheet. The page exposed the six editor tabs and the subtitle controls without an initial page error. The server now serves `/fonts`, while `editor.css` references the bundled Noto Sans Myanmar and Pyidaungsu font files through that route.

For the automated local upload check only, the hidden `#videoInput` element was temporarily made visible in the browser. Its file input was detected correctly. This DOM-only test adjustment is not stored in the application source.

The supplied `1000130858.mp4` sample uploaded into the native browser preview and reported `4.8 MB · 209 sec · Ready`. Changing the subtitle text, font, size, colour and X/Y controls updated the overlay locally. The preview retained the same video source while those edits occurred, and `document.fonts.check` confirmed that the bundled `Pyidaungsu Bold` face loaded successfully.

After adding the verified membership gate, the latest local page showed the Email/Password account controls together with the original Simple Gemini-key section. Its browser console contained no loading or runtime errors. Local development has no Supabase configuration, so the page correctly remains in an unsigned account state; an actual member login requires the deployment secrets described in the README.

The local `/api/auth-config` endpoint returned `{"enabled":"false"}`, and the Supabase browser library loaded. The visible status still showed its initial loading text, so the disabled-configuration display needs an explicit follow-up correction before delivery.

The current document did load the intended `editor.js?v=20260827-0830`, reached `complete` state, and exposed `initializeAuth`. This narrows the remaining issue to the asynchronous initialization path rather than an asset cache or missing browser library.

A direct post-load timer invocation of `initializeAuth` ran successfully. The initialization call therefore needs a deterministic deferred invocation in addition to the load listener, which is addressed in the subsequent source fix.

The final static account state now reads `Account ဝင်မယ်` and `Account ဝင်ပြီး Plan ကိုအလိုအလျောက်စစ်ပါ`, avoiding an incorrect indefinite loading label before Supabase production secrets are configured. The original One Team editor controls remain available beneath it.

On the final editor build, the sample video again uploaded into the native player and the editor reported `Ready to edit` with `4.8 MB · 209 sec · Ready`. The temporary visible file input was used only by browser automation and is not part of the delivered UI.

The browser automation click on the Blur tab did not change the captured tab state, but invoking the same `selectTab('blur')` browser handler switched the control pane to Blur and resulted in zero visible subtitle overlays and zero blur overlays before a blur box was added. This verifies the tab-specific overlay visibility logic; the click mismatch is limited to the automation interaction, not the handler itself.

Adding a blur box created exactly one blur overlay while the subtitle overlay remained hidden. A controlled 16:9 letterbox check produced a visible source rectangle of `560.16 × 315.09` at top `122.53`; the blur box top (`217.06`) and height (`50.41`) matched the expected values from that visible rectangle, rather than being calculated from the full square stage.

The initial logo-tab browser check returned an older settings payload without the new logo fields, although the server had restarted. The page still referenced the previous script version query string; this is a static-cache issue to correct with a new editor script version before final verification.

After the version update, the browser loaded `editor.js?v=20260827-0845`. The Logo tab controls (`logoEnabled` and `logoSize`) existed, and the export settings object included `logo_enabled`, confirming that the current source rather than the cached browser script is active.

The first current-logo preview check was performed before a new video had been uploaded after the server restart, so its hidden stage had zero dimensions and is not treated as a placement test. The video input was then made visible only for the next browser-automation upload check.

The sample video uploaded into the current Logo tab and created one logo overlay, with zero subtitle and blur overlays. The generated settings contained the expected enabled/text/size/X/Y values. The overlay still measured 72px at `(0, 0)`, so direct logo placement needs one more geometry check for the transition from metadata loading to the visible native video rect before delivery.

After native video metadata was available, the video was `720 × 720`, the stage was `560.16 × 560.16`, and the visible rect filled the stage. A direct redraw correctly placed the 30% logo at left `319.31`, top `387.92`, width `168.05`. The remaining code change is to schedule that redraw after the browser has completed the metadata/layout transition.

For the final retest, the new metadata-delay handler was loaded from `editor.js?v=20260827-0845`, and the hidden local video input was made visible only for automated sample upload.

After that upload, native video reported ready state 4 and the visible source rect measured `560.16 × 560.16`. In the Logo tab, the enabled `Khant Happy · ကိုခန့်` logo with size 30, X 72 and Y 78 created one logo overlay at left `409.03`, top `445.73`, width `123.23`, with zero subtitle overlays. This confirms that the current selection is previewed directly over the loaded video and that the Logo tab hides unrelated overlays.

The revised editor page visibly labels the access route `Simple Trial · Gemini API Key` and states its seven-day own-key rule. The Voice tab contains four Gemini voice choices and the automatic Movie Recap voice description, with no text input or textarea for a separate user-typed text-to-speech page.

The final browser check confirmed the Simple Trial title, the automatic Gemini narration description, four available Gemini narration voices, and zero manual text-to-speech input fields in the Voice tab.
