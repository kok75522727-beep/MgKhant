from datetime import datetime, timezone

import pytest

from membership import (
    SIMPLE_TRIAL_DAILY_LIMIT,
    SIMPLE_TRIAL_DAYS,
    VIP_TIERS,
    MembershipError,
    credits_for_duration,
    effective_plan,
    evaluate_export,
    myanmar_export_day,
    simple_trial_days_remaining,
    simple_trial_expired,
)
from media_engine import fitted_source_rect, srt_to_ass


def member(**overrides):
    return {"status": "active", "plan": "simple", "role": "member", "credit_balance": 0, **overrides}


def test_final_paid_plans_use_user_gemini_key_and_three_daily_exports():
    assert [(tier["price"], tier["daily_limit"], tier["days"], tier["key_mode"]) for tier in VIP_TIERS.values()] == [
        (15000, 3, 30, "user"), (30000, 3, 30, "user")
    ]
    assert SIMPLE_TRIAL_DAILY_LIMIT == 3
    assert SIMPLE_TRIAL_DAYS == 7
    for tier in ("simple_vip", "vip"):
        ent = evaluate_export(member(plan="pro", subscription_tier=tier), 3600, 2)
        assert (ent.route, ent.key_mode, ent.tier) == ("user_key", "user", tier)
        with pytest.raises(MembershipError, match="လူသုံးများနေပါသည်"):
            evaluate_export(member(plan="pro", subscription_tier=tier), 3600, 3)


def test_trial_allows_three_exports_and_owner_bonus_is_per_user():
    assert evaluate_export(member(), 3600, 0).route == "trial"
    assert evaluate_export(member(), 3600, 2).route == "trial"
    with pytest.raises(MembershipError, match="လူသုံးများနေပါသည်"):
        evaluate_export(member(), 3600, 3)
    boosted = member(daily_quota_bonus=2, quota_bonus_expires_at="2099-01-01T00:00:00Z")
    assert evaluate_export(boosted, 3600, 4).route == "trial"
    with pytest.raises(MembershipError, match="လူသုံးများနေပါသည်"):
        evaluate_export(boosted, 3600, 5)


def test_no_credit_pack_or_customer_facing_minute_cap():
    assert credits_for_duration(180) == 0
    assert credits_for_duration(3600) == 0
    assert evaluate_export(member(plan="pro", subscription_tier="vip"), 3600, 0).credits_required == 0


def test_expiry_and_myanmar_export_day():
    assert effective_plan(member(plan="pro", plan_expires_at="2025-01-01T00:00:00Z")) == "none"
    assert simple_trial_expired(member(plan_expires_at="2025-01-01T00:00:00Z"))
    assert myanmar_export_day(datetime(2026, 8, 26, 18, 0, tzinfo=timezone.utc)) == "2026-08-27"


def test_simple_trial_days_remaining_uses_stored_expiry():
    now = datetime(2026, 8, 27, 0, 0, tzinfo=timezone.utc)
    assert simple_trial_days_remaining(member(plan_expires_at="2026-09-02T01:00:00Z"), now) == 7
    assert simple_trial_days_remaining(member(plan_expires_at="2026-08-26T23:59:00Z"), now) == 0


def test_owner_bypasses_customer_quota_but_not_other_customer_rules(monkeypatch):
    monkeypatch.setenv("ONE_TEAM_ADMIN_EMAIL", "owner@example.com")
    owner = member(email="owner@example.com", role="admin", plan="pro", subscription_tier="vip")
    entitlement = evaluate_export(owner, 3600, 999)
    assert (entitlement.route, entitlement.plan, entitlement.key_mode) == ("owner", "pro", "user")


def test_letterboxed_output_uses_source_visible_rect_for_subtitle_position():
    rect = fitted_source_rect({"width": 1920, "height": 1080}, 720, 1280)
    assert rect == {"x": 0, "y": 437, "width": 720, "height": 405}
    ass = srt_to_ass("1\n00:00:00,000 --> 00:00:01,000\nHello", {"subtitle_x": 50, "subtitle_y": 50}, 720, 1280, rect)
    assert "\\pos(360,640)" in ass
